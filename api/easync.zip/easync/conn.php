<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "web_billing";
 $dbpass = "create123";
 $db = "web_billing";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }
   
?>